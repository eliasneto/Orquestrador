# Changelog

## [1.0.1] - 2025-12-12
### Corrigido
- Instalação dos drivers Microsoft ODBC no Dockerfile.
- Correção no mapeamento de volumes (/app vs /orquestrador).

## [1.0.0] - 2025-12-01
### Adicionado
- Versão inicial do sistema.
- Cadastro de Automações.
- Execução de Jobs Python.