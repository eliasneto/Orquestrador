Pasta usada para armazenar arquivos temporários de execução das automações.
Os subdiretórios job_xxx são ignorados pelo Git.
