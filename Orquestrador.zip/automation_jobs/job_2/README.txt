Pasta dedicada da automação.
Coloque aqui:
- requirements.txt (opcional)
- script principal indicado em 'Arquivo principal (main)'
- demais arquivos necessários.
