# ==========================================================
#  IMPORTAÇÕES
# ==========================================================
import os
import re
import time
import base64
import pandas as pd

from selene import browser, be, by
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options

from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By as SBy
from selenium.webdriver.common.action_chains import ActionChains
from selenium.common.exceptions import StaleElementReferenceException

from rich.console import Console
from rich.traceback import install as rich_install

rich_install()
console = Console()

# ==========================================================
#  CONFIGURAÇÕES
# ==========================================================
CAMINHO_PLANILHA = os.path.join("entrada", "entrada.xlsx")

NOME_COL_STATUS = "status"
NOME_COL_MENSAGEM = "mensagem"

NOME_COL_CLIENTE_ID = "Cliente_ID"  # ajuste se for outro nome

NOME_COL_CONTRATO = "Login_Contrato_ID"
NOME_COL_PLANO = "Login_Plano_ID"
NOME_COL_LOGIN = "Login_Login"
NOME_COL_SENHA = "Login_Senha_Cliente"

NOME_COL_CEP = "End_CEP"
NOME_COL_ENDERECO = "End_Logradouro"
NOME_COL_NUMERO = "End_Numero"
NOME_COL_BAIRRO = "End_Bairro"
NOME_COL_CIDADE_ID = "End_Cidade_ID"

ARQUIVO_CREDENCIAIS = "credenciais.txt"


# ==========================================================
#  HELPERS
# ==========================================================
def _safe_filename(texto: str, maxlen: int = 120) -> str:
    texto = (texto or "").strip()
    texto = re.sub(r'[\\/*?:"<>|]+', "_", texto)
    texto = re.sub(r"\s+", "_", texto)
    texto = texto.strip("._-")
    return (texto[:maxlen] if texto else "sem_nome")


def _is_processado(valor) -> bool:
    if valor is None:
        return False
    try:
        if pd.isna(valor):
            return False
    except Exception:
        pass
    s = str(valor).strip().lower()
    return s.startswith("processad")  # "processado" ou "processada"


def salvar_excel_atomic(df: pd.DataFrame, caminho_xlsx: str):
    """
    Salva a planilha em tmp e troca (bom para Linux/Docker).
    """
    pasta = os.path.dirname(caminho_xlsx) or "."
    os.makedirs(pasta, exist_ok=True)

    tmp = os.path.join(pasta, "__tmp_entrada.xlsx")
    df.to_excel(tmp, index=False, engine="openpyxl")
    os.replace(tmp, caminho_xlsx)


def set_input_js(css_selector: str, valor: str):
    el = browser.element(css_selector).should(be.present)
    browser.driver.execute_script(
        """
        arguments[0].scrollIntoView({block: 'center'});
        arguments[0].value = arguments[1];
        arguments[0].dispatchEvent(new Event('input', { bubbles: true }));
        arguments[0].dispatchEvent(new Event('change', { bubbles: true }));
        """,
        el(),
        valor
    )


def preencher_autocomplete(css_selector: str, valor: str, wait_lista=0.8):
    """
    Campo lookup/autocomplete:
    digita -> espera -> seta pra baixo -> ENTER -> TAB
    """
    el = browser.element(css_selector).should(be.visible)
    el.click()
    el.send_keys(Keys.CONTROL, "a")
    el.type(str(valor))
    time.sleep(wait_lista)

    active = browser.driver.switch_to.active_element
    active.send_keys(Keys.ARROW_DOWN)
    active.send_keys(Keys.ENTER)
    time.sleep(0.2)
    active.send_keys(Keys.TAB)
    time.sleep(0.2)

def forcar_remocao_2fa():
    print("🛡️ Verificando e removendo modal 2FA...", flush=True)
    for _ in range(5):
        browser.driver.execute_script("""
            const m1 = document.getElementById("Auth2FA");
            if (m1) m1.remove();

            const m2 = document.querySelector("div[class*='styles-module__containerPage']");
            if (m2) m2.remove();

            const overlays = document.querySelectorAll("#backgroundContent, .MuiBackdrop-root, div[class*='overlay']");
            overlays.forEach(el => el.remove());

            const tfa = document.querySelector("tfa-scheme-light");
            if (tfa) tfa.remove();
        """)
        time.sleep(0.2)
    print("✅ Limpeza de 2FA concluída.", flush=True)


def _notificacao_snapshot():
    return browser.driver.execute_script("""
        const host = document.querySelector('#ixc_notification');
        if (!host) return {count: 0, text: ''};

        const root = host.shadowRoot || host;

        const nodes = root.querySelectorAll(
          '[role="alert"], .toast, .toast-error, .toast-warning, .toast-success, .notification, .snackbar, .MuiAlert-root'
        );

        const text = (root.innerText || root.textContent || '').trim();
        return {count: nodes.length, text};
    """)


def _tem_aba_invalida() -> bool:
    return bool(browser.driver.execute_script(
        "return document.querySelectorAll('.formTab-tab-invalid').length > 0;"
    ))


def _pegar_form_login():
    forms = browser.driver.find_elements(SBy.CSS_SELECTOR, "form.ixc-modal, form.modal2.ixc-modal")
    visiveis = [f for f in forms if f.is_displayed()]
    if not visiveis:
        raise Exception("Nenhum modal (form.ixc-modal) visível para salvar.")

    for f in visiveis:
        action = (f.get_attribute("action") or "").lower()
        if "radusuarios" in action:
            return f

    for f in visiveis:
        try:
            if f.find_elements(SBy.CSS_SELECTOR, "input#login"):
                return f
        except Exception:
            pass

    return visiveis[-1]


def _botao_salvar_info(form):
    return browser.driver.execute_script("""
        const form = arguments[0];
        const btn = form.querySelector("button[title='Alt+S'][type='submit']");
        if (!btn) return {exists:false, disabled:true, reason:"Botão Salvar (Alt+S) não encontrado"};
        const disabled = !!(btn.disabled || btn.classList.contains('disab') || btn.getAttribute('aria-disabled') === 'true');
        return {exists:true, disabled, className: btn.className || ''};
    """, form)


def _diagnostico(form):
    return browser.driver.execute_script("""
        const form = arguments[0];

        const invalidTabs = [...document.querySelectorAll('.formTab-tab-invalid .tabTitle, .formTab-tab-invalid a')]
          .map(e => (e.innerText||'').trim()).filter(Boolean);

        const invalidFields = [...form.querySelectorAll('[aria-invalid="true"], .invalid, .error, .has-error')]
          .map(el => el.id || el.name || el.getAttribute('data-name') || el.tagName)
          .filter(Boolean).slice(0, 10);

        return { invalidTabs, invalidFields };
    """, form)


def _js_click(el):
    browser.driver.execute_script("arguments[0].scrollIntoView({block:'center', inline:'center'});", el)
    browser.driver.execute_script("arguments[0].click();", el)


def salvar_e_validar(timeout=20, poll=0.25):
    form = _pegar_form_login()
    action_antes = (form.get_attribute("action") or "")
    snap_antes = _notificacao_snapshot()

    info = _botao_salvar_info(form)
    if not info.get("exists"):
        return False, info.get("reason", "Botão salvar não encontrado")

    if info.get("disabled"):
        diag = _diagnostico(form)
        msg = "Salvar está DESABILITADO (provável campo obrigatório/lookup não validado)."
        if diag.get("invalidTabs"):
            msg += f" Abas inválidas: {', '.join(diag['invalidTabs'])}"
        if diag.get("invalidFields"):
            msg += f" Campos inválidos: {', '.join(diag['invalidFields'])}"
        return False, msg

    # tenta salvar
    btn = form.find_element(SBy.CSS_SELECTOR, "button[title='Alt+S'][type='submit']")
    try:
        _js_click(btn)
    except Exception:
        ActionChains(browser.driver).key_down(Keys.ALT).send_keys('s').key_up(Keys.ALT).perform()

    t_end = time.time() + timeout
    while time.time() < t_end:
        if _tem_aba_invalida():
            snap = _notificacao_snapshot()
            return False, snap.get("text") or "Validação: existe aba inválida."

        snap = _notificacao_snapshot()
        if (snap.get("count", 0) > snap_antes.get("count", 0)) or (snap.get("text") and snap.get("text") != snap_antes.get("text")):
            text = snap.get("text", "")
            low = text.lower()
            if ("preencha" in low) or ("obrigat" in low) or ("erro" in low) or ("alert" in low):
                return False, text
            if ("sucesso" in low) or ("salv" in low):
                return True, text

        try:
            action_agora = (form.get_attribute("action") or "")
            if action_agora and action_agora != action_antes:
                return True, f"Salvo (action mudou: {action_antes} -> {action_agora})"
        except StaleElementReferenceException:
            return True, "Salvo (form foi recriado/removido)."

        time.sleep(poll)

    return False, f"Timeout: sem confirmação. action={form.get_attribute('action') or ''}"


def salvar_print_unico(login_nome: str, numero_linha: int, pasta_destino: str):
    """
    ✅ Um único print: LOGINEXCEL_NUMEROLINHA.png
    Ex: REDE_WAN_UNID_AGRESTINA_1.png

    Regra: sempre tenta disparar o salvar (Alt+S / click) e espera o popup aparecer,
    depois tira print FULL PAGE com CDP.
    """
    login_ok = _safe_filename(login_nome)
    nome_arquivo = f"{login_ok}_{numero_linha}.png"
    caminho_png = os.path.join(pasta_destino, nome_arquivo)

    # 1) tenta acionar salvar (para disparar popup/validação)
    try:
        form = _pegar_form_login()
        try:
            btn = form.find_element(SBy.CSS_SELECTOR, "button[title='Alt+S']")
            browser.driver.execute_script("arguments[0].click();", btn)
        except Exception:
            ActionChains(browser.driver).key_down(Keys.ALT).send_keys('s').key_up(Keys.ALT).perform()
    except Exception:
        pass

    # 2) espera popup/validação aparecer (curto)
    t_end = time.time() + 2.0
    while time.time() < t_end:
        snap = _notificacao_snapshot()
        if (snap.get("text") or "").strip():
            break
        if _tem_aba_invalida():
            break
        time.sleep(0.2)

    # 3) screenshot FULL PAGE (CDP)
    try:
        data = browser.driver.execute_cdp_cmd(
            "Page.captureScreenshot",
            {"format": "png", "captureBeyondViewport": True, "fromSurface": True}
        )
        with open(caminho_png, "wb") as f:
            f.write(base64.b64decode(data["data"]))
        print(f"📸 Print salvo: {caminho_png}", flush=True)
        return
    except Exception:
        pass

    # fallback: viewport
    browser.driver.save_screenshot(caminho_png)
    print(f"📸 Print (fallback) salvo: {caminho_png}", flush=True)

# ==========================================================
#  ENTRADA PLANILHA
# ==========================================================
print("📘 CARREGANDO PLANILHA...", flush=True)
if not os.path.exists(CAMINHO_PLANILHA):
    print(f"❌ Planilha não encontrada em: {CAMINHO_PLANILHA}", flush=True)
    raise SystemExit(1)

df_status = pd.read_excel(CAMINHO_PLANILHA)

if NOME_COL_STATUS not in df_status.columns:
    df_status[NOME_COL_STATUS] = ""
if NOME_COL_MENSAGEM not in df_status.columns:
    df_status[NOME_COL_MENSAGEM] = ""

df_status[NOME_COL_STATUS] = df_status[NOME_COL_STATUS].astype("object")
df_status[NOME_COL_MENSAGEM] = df_status[NOME_COL_MENSAGEM].astype("object")

print(f"📋 Total de registros carregados: {len(df_status)}", flush=True)


# ==========================================================
#  NAVEGADOR (DOCKER/LINUX)
# ==========================================================
import sys
from pathlib import Path
from webdriver_manager.chrome import ChromeDriverManager

def rodando_em_docker() -> bool:
    # padrão: arquivo existe em containers
    if os.path.exists("/.dockerenv"):
        return True
    # fallback: env flag se você quiser setar manualmente
    if os.getenv("RUNNING_IN_DOCKER", "").lower() in ("1", "true", "yes"):
        return True
    return False


print("🌐 INICIANDO NAVEGADOR...", flush=True)

options = Options()

# Controla headless por variável de ambiente:
# Windows: set HEADLESS=1
# Linux/Docker: export HEADLESS=1
headless = os.getenv("HEADLESS", "0").lower() in ("1", "true", "yes")

if headless:
    options.add_argument("--headless=new")

options.add_argument("--window-size=1920,1080")
options.add_argument("--disable-blink-features=AutomationControlled")
options.add_experimental_option("detach", False)

# Flags só fazem sentido em Linux/Docker
if rodando_em_docker():
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    options.add_argument("--disable-gpu")

# Se você precisar apontar o binário do Chrome no Docker, use:
# CHROME_BIN=/usr/bin/google-chrome
chrome_bin = os.getenv("CHROME_BIN")
if chrome_bin:
    options.binary_location = chrome_bin


# Escolhe o chromedriver correto
if rodando_em_docker():
    driver_path = "/usr/bin/chromedriver"
    if not Path(driver_path).is_file():
        raise RuntimeError(
            f"Rodando em Docker/Linux, mas não achei o chromedriver em {driver_path}.\n"
            f"Instale no container (recomendado) OU set RUNNING_IN_DOCKER=0 para usar webdriver_manager."
        )
    service = Service(driver_path)
else:
    # Windows / fora do docker: baixa e usa automaticamente
    service = Service(ChromeDriverManager().install())

browser.config.driver = webdriver.Chrome(service=service, options=options)
browser.config.timeout = 10



# ==========================================================
#  CREDENCIAIS
# ==========================================================
print("🔐 INICIANDO LOGIN NO IXC", flush=True)

if not os.path.exists(ARQUIVO_CREDENCIAIS):
    print(f"❌ Crie '{ARQUIVO_CREDENCIAIS}' com login na 1ª linha e senha na 2ª.", flush=True)
    raise SystemExit(1)

with open(ARQUIVO_CREDENCIAIS, "r", encoding="utf-8") as f:
    linhas = f.readlines()
    USUARIO_IXC = linhas[0].strip()
    SENHA_IXC = linhas[1].strip()

print("✅ Credenciais carregadas do arquivo.", flush=True)


# ==========================================================
#  LOGIN
# ==========================================================
browser.open("https://megainfraestrutura.com.br/app/login")

browser.element("#email").should(be.visible).type(USUARIO_IXC)
browser.element("#btn-next-login").click()

browser.element("#password").should(be.visible).type(SENHA_IXC)

btn_login = browser.element("#btn-enter-login")
btn_login.click()
time.sleep(0.5)
if btn_login.matching(be.visible):
    print("⚠️ Primeiro clique falhou, tentando o segundo...", flush=True)
    btn_login.click()

print("⛔ Removendo modal 2FA (forçado)...", flush=True)
for _ in range(10):
    browser.driver.execute_script("""
        const m1 = document.getElementById("Auth2FA");
        if (m1) m1.remove();

        const m2 = document.querySelector("div[class*='styles-module__containerPage']");
        if (m2) m2.remove();

        const overlay = document.getElementById("backgroundContent");
        if (overlay) overlay.remove();

        const tfa = document.querySelector("tfa-scheme-light");
        if (tfa) tfa.remove();
    """)
    time.sleep(0.3)
print("✅ Modal 2FA REMOVIDO!", flush=True)

print("⏳ Aguardando dashboard carregar...", flush=True)
browser.wait.until(lambda _: "main" in browser.driver.current_url)

forcar_remocao_2fa()
print("🎉 LOGIN FINALIZADO COM SUCESSO!", flush=True)


# ==========================================================
#  SAÍDA (DENTRO DA PASTA DO RESULTADO)
# ==========================================================
os.makedirs("saida", exist_ok=True)

RUN_ID = time.strftime('%Y%m%d_%H%M%S')
PASTA_RUN = os.path.join("saida", f"run_{RUN_ID}")
os.makedirs(PASTA_RUN, exist_ok=True)

ARQUIVO_SAIDA = f"resultado_{RUN_ID}.csv"
CAMINHO_SAIDA = os.path.join(PASTA_RUN, ARQUIVO_SAIDA)

PASTA_EVID_ERROS = os.path.join(PASTA_RUN, "erros")
os.makedirs(PASTA_EVID_ERROS, exist_ok=True)

print("🔁 INICIANDO PROCESSAMENTO EM LOTE (modo LOOP)...", flush=True)

for indice_linha, row_data in df_status.iterrows():
    numero_linha_excel = indice_linha + 1
    login_atual = ""
    valor_cliente = ""
    evidencia_salva = False

    # ✅ PULAR se já foi processado
    if _is_processado(row_data.get(NOME_COL_STATUS)):
        login_pulo = row_data.get(NOME_COL_LOGIN, "")
        print(f"⏭️ Pulando linha {numero_linha_excel} (status=processado) | login={login_pulo}", flush=True)
        continue

    print(f"➡️ PROCESSANDO LINHA {numero_linha_excel}", flush=True)

    try:
        # MENU CADASTROS
        time.sleep(2)
        browser.element(by.xpath("//a[normalize-space()='Cadastros']")).should(be.visible).click()

        # CLIENTES
        time.sleep(1)
        browser.element("#menu_item_cliente a").should(be.visible).click()

        # FILTRO ID
        time.sleep(1)
        browser.element("//span[contains(@class,'selectedColumn')]").should(be.visible).click()
        time.sleep(0.5)
        browser.element(by.xpath("//li[normalize-space()='ID']")).should(be.visible).click()

        # BUSCA CLIENTE ID
        valor_bruto = row_data[NOME_COL_CLIENTE_ID]
        if pd.isna(valor_bruto):
            raise ValueError(f"Coluna '{NOME_COL_CLIENTE_ID}' vazia.")
        valor_cliente = str(int(valor_bruto)) if isinstance(valor_bruto, (int, float)) else str(valor_bruto).strip()

        campo_busca = browser.element("input.gridActionsSearchInput").should(be.visible)
        campo_busca.clear()
        campo_busca.type(valor_cliente)
        campo_busca.press_enter()

        # ABRIR CLIENTE
        id_linha_grid = f"row{valor_cliente}"
        row_el = browser.element(by.xpath(f"//table[@id='grid_1']//tr[@id='{id_linha_grid}']")).should(be.visible)
        row_el.double_click()

        # ABA LOGINS
        time.sleep(1)
        browser.element(by.xpath("//ul[contains(@class,'abas_list')]//a[normalize-space()='Logins']")).should(be.visible).click()

        # BOTÃO NOVO (grid Logins)
        time.sleep(2)
        xpath_botao_novo = (
            "//div[contains(@class,'ixc-grids')"
            " and .//div[contains(@class,'grid-title') and normalize-space()='Logins']]"
            "//div[contains(@class,'gridActions')]"
            "//button[@name='novo']"
        )
        botao_novo = browser.element(by.xpath(xpath_botao_novo)).should(be.visible)
        try:
            botao_novo.should(be.clickable).click()
        except Exception:
            browser.driver.execute_script("arguments[0].click();", botao_novo())

        # FORM: CONTRATO / PLANO / LOGIN / SENHA
        time.sleep(1)

        contrato = row_data[NOME_COL_CONTRATO]
        if pd.isna(contrato):
            raise ValueError(f"Coluna '{NOME_COL_CONTRATO}' vazia.")
        contrato_str = str(int(contrato)) if isinstance(contrato, (int, float)) else str(contrato).strip()
        preencher_autocomplete("#id_contrato", contrato_str, wait_lista=0.8)

        plano = row_data[NOME_COL_PLANO]
        if pd.isna(plano):
            raise ValueError(f"Coluna '{NOME_COL_PLANO}' vazia.")
        plano_str = str(int(plano)) if isinstance(plano, (int, float)) else str(plano).strip()
        preencher_autocomplete("#id_grupo", plano_str, wait_lista=0.8)

        login_val = row_data[NOME_COL_LOGIN]
        if pd.isna(login_val):
            raise ValueError(f"Coluna '{NOME_COL_LOGIN}' vazia.")
        login_str = str(int(login_val)) if isinstance(login_val, (int, float)) else str(login_val).strip()
        login_atual = login_str

        el_login = browser.element("#login").should(be.visible)
        el_login.click()
        el_login.clear()
        el_login.type(login_str)
        browser.driver.switch_to.active_element.send_keys(Keys.TAB)

        senha_val = row_data[NOME_COL_SENHA]
        if pd.isna(senha_val):
            raise ValueError(f"Coluna '{NOME_COL_SENHA}' vazia.")
        senha_str = str(senha_val).strip()

        campo_senha = browser.all("#senha").element_by(be.visible)
        browser.driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", campo_senha())
        campo_senha.click()
        campo_senha.clear()
        campo_senha.type(senha_str)
        browser.driver.switch_to.active_element.send_keys(Keys.TAB)

        # OBSERVAÇÕES
        time.sleep(1)
        aba_obs = browser.all(
            by.xpath("//li[contains(@class,'formTab')]//a[contains(@class,'tabTitle') and normalize-space()='Observações']")
        ).element_by(be.visible)
        try:
            aba_obs.click()
        except Exception:
            browser.driver.execute_script("arguments[0].click();", aba_obs())

        texto_obs = (
            "PARCEIRO:\n"
            "DATA DE ATIVAÇÃO LINK:\n"
            "DATA VALIDAÇÃO CLIENTE:\n"
            "DESIGNADOR:\n"
        )
        campos_obs = browser.all("textarea#obs, textarea[name='obs']")
        campo_obs = campos_obs.element_by(be.visible)
        browser.driver.execute_script(
            """
            arguments[0].scrollIntoView({block: 'center'});
            arguments[0].value = arguments[1];
            arguments[0].dispatchEvent(new Event('input', { bubbles: true }));
            arguments[0].dispatchEvent(new Event('change', { bubbles: true }));
            """,
            campo_obs(), texto_obs
        )

        # ENDEREÇO
        time.sleep(1)
        aba_end = browser.element("ul.nav.abas_list a.tabTitle[rel='8']").should(be.present)
        browser.driver.execute_script("""
            const el = arguments[0];
            el.scrollIntoView({block:'center'});
            el.dispatchEvent(new MouseEvent('click', {bubbles:true,cancelable:true,view:window}));
        """, aba_end())

        time.sleep(0.5)
        chk = browser.element("#endereco_padrao_cliente").should(be.present)
        try:
            if chk().is_selected():
                chk.click()
        except Exception:
            browser.driver.execute_script("""
                const el = arguments[0];
                if (el.checked) {
                    el.checked = false;
                    el.dispatchEvent(new Event('change', { bubbles: true }));
                }
            """, chk())

        cep_val = row_data[NOME_COL_CEP]
        if not pd.isna(cep_val):
            set_input_js("div.panel.mostrando input#cep", str(cep_val).strip())

        end_val = row_data[NOME_COL_ENDERECO]
        if not pd.isna(end_val):
            set_input_js("div.panel.mostrando input#endereco", str(end_val).strip())

        num_val = row_data[NOME_COL_NUMERO]
        if not pd.isna(num_val):
            set_input_js("div.panel.mostrando input#numero", str(num_val).strip())

        bai_val = row_data[NOME_COL_BAIRRO]
        if not pd.isna(bai_val):
            set_input_js("div.panel.mostrando input#bairro", str(bai_val).strip())

        cidade_val = row_data[NOME_COL_CIDADE_ID]
        if pd.isna(cidade_val):
            raise ValueError(f"Coluna '{NOME_COL_CIDADE_ID}' vazia.")
        cidade_str = str(int(cidade_val)) if isinstance(cidade_val, (int, float)) else str(cidade_val).strip()
        preencher_autocomplete("div.panel.mostrando #cidade", cidade_str, wait_lista=0.8)

        # SALVAR (se falhar, print único)
        print("💾 Tentando SALVAR e validar...", flush=True)
        salvou, msg = salvar_e_validar(timeout=20)
        print(("✅ " if salvou else "❌ ") + msg, flush=True)

        df_status.at[indice_linha, NOME_COL_MENSAGEM] = msg

        if not salvou:
            salvar_print_unico(
                login_nome=(login_atual or f"cliente_{valor_cliente}"),
                numero_linha=numero_linha_excel,
                pasta_destino=PASTA_EVID_ERROS
            )
            evidencia_salva = True
            raise Exception("Falha ao salvar (print gerado).")

    except Exception as e:
        df_status.at[indice_linha, NOME_COL_MENSAGEM] = str(e)

        if not evidencia_salva:
            try:
                salvar_print_unico(
                    login_nome=(login_atual or f"cliente_{valor_cliente}"),
                    numero_linha=numero_linha_excel,
                    pasta_destino=PASTA_EVID_ERROS
                )
            except Exception:
                pass

        print("🚑 RECUPERAÇÃO: ESC + refresh...", flush=True)
        try:
            body = browser.driver.find_element(SBy.TAG_NAME, "body")
            body.send_keys(Keys.ESCAPE)
            time.sleep(0.3)
            body.send_keys(Keys.ESCAPE)

            browser.driver.refresh()
            time.sleep(5)
            browser.wait.until(lambda _: "main" in browser.driver.current_url)
            forcar_remocao_2fa()
        except Exception as e2:
            print(f"💀 Recuperação falhou: {e2}", flush=True)

    finally:
        # ✅ SEMPRE marca como processado ao final da linha (sucesso ou erro)
        df_status.at[indice_linha, NOME_COL_STATUS] = "processado"

        # CSV parcial
        df_status.to_csv(CAMINHO_SAIDA, index=False, sep=";")

        # ✅ atualiza também a planilha de entrada (persistente)
        try:
            salvar_excel_atomic(df_status, CAMINHO_PLANILHA)
        except Exception as e_save:
            print(f"⚠️ Não consegui salvar entrada.xlsx: {e_save}", flush=True)

        print(f"🏁 Fim da linha {numero_linha_excel}", flush=True)

print("✅ PROCESSO FINALIZADO.", flush=True)
