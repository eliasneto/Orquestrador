from django.apps import AppConfig


class MonitorserverConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'monitorServer'
